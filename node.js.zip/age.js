let age=22;
b=true;
if(age>18|| b==true)
{
    console.log("you can drive");

}
else{
    console.log("i cannt drive");
}